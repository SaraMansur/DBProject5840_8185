async function loadCustomers() {
  try {
    const response = await fetch('http://localhost:3000/api/customer');
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    const customers = await response.json();
    const tbody = document.querySelector('#customerTable tbody');
    tbody.innerHTML = '';
    customers.forEach(customer => {
      const row = document.createElement('tr');
      row.innerHTML = `<td>${customer.cid}</td><td>${customer.cname}</td><td>${customer.cphone || ''}</td>`;
      tbody.appendChild(row);
    });
  } catch (err) {
    console.error('Error loading customers:', err);
    alert('שגיאה בטעינת לקוחות: ' + err.message);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  loadCustomers();
  document.querySelector('#addCustomer').addEventListener('click', () => {
    console.log('Add button clicked'); // דיבוג
    document.querySelector('#addForm').style.display = 'block';
  });

  document.querySelector('#saveCustomer').addEventListener('click', async () => {
    console.log('Save button clicked'); // דיבוג
    const cid = document.querySelector('#newCid').value;
    const cname = document.querySelector('#newCname').value;
    const cphone = document.querySelector('#newCphone').value;
    if (!cid || !cname) {
      alert('מספר לקוח ושם לקוח הם שדות חובה');
      return;
    }
    try {
      const response = await fetch('http://localhost:3000/api/customer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cid, cname, cphone: cphone || null })
      });
      if (response.ok) {
        console.log('Customer added successfully'); // דיבוג
        document.querySelector('#addForm').style.display = 'none';
        document.querySelector('#newCid').value = '';
        document.querySelector('#newCname').value = '';
        document.querySelector('#newCphone').value = '';
        loadCustomers();
      } else {
        const errorText = await response.text();
        console.error('Error adding customer:', errorText); // דיבוג
        alert('שגיאה בהוספת לקוח: ' + errorText);
      }
    } catch (err) {
      console.error('Error adding customer:', err);
      alert('שגיאה בחיבור לשרת: ' + err.message);
    }
  });

  document.querySelector('#cancelCustomer').addEventListener('click', () => {
    console.log('Cancel button clicked'); // דיבוג
    document.querySelector('#addForm').style.display = 'none';
    document.querySelector('#newCid').value = '';
    document.querySelector('#newCname').value = '';
    document.querySelector('#newCphone').value = '';
  });
});