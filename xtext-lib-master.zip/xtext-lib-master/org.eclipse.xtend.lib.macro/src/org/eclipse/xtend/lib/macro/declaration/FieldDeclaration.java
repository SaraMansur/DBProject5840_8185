/*******************************************************************************
 * Copyright (c) 2013 itemis AG (http://www.itemis.eu) and others.
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *******************************************************************************/
package org.eclipse.xtend.lib.macro.declaration;

import org.eclipse.xtend.lib.macro.expression.Expression;

import com.google.common.annotations.Beta;

/**
 * @author Sven Efftinge
 * @noimplement This interface is not intended to be implemented by clients.
 */
@Beta
public interface FieldDeclaration extends MemberDeclaration {
	
	/**
	 * @return whether this field is declared 'final'
	 */
	boolean isFinal();

	/**
	 * @return whether this field is declared 'static'
	 */
	boolean isStatic();
	
	/**
	 * @return whether this field is declared 'transient'
	 */
	boolean isTransient();
	
	/**
	 * @return whether this field is declared 'volatile'
	 */
	boolean isVolatile();
	
	/**
	 * @return the initializer. <code>null</code> if no initializer is present or this is an external element.
	 */
	Expression getInitializer();
	
	/**
	 * @return the type of this expression. <code>null</code> if this is a source field declaration and the type is inferred from the initializer.
	 */
	TypeReference getType();
	
}